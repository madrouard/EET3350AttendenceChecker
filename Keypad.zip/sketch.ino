#include <Keypad.h>

const uint8_t LEDS = 12;
const uint8_t ROWS = 4;
const uint8_t COLS = 4;

char keys[ROWS][COLS] = {
  { '1', '2', '3', 'A' },
  { '4', '5', '6', 'B' },
  { '7', '8', '9', 'C' },
  { '*', '0', '#', 'D' }
};

// Pins connected to LED1, LED2, LED3, ...LED12
uint8_t ledPins[LEDS] = { 9, 6, 3,};
uint8_t rowPins[ROWS] = { 26, 22, 21, 20 }; // Pins connected to R1, R2, R3, R4
uint8_t colPins[COLS] = { 19, 18, 17, 16 }; // Pins connected to C1, C2, C3, C4


Keypad keypad = Keypad(makeKeymap(keys), rowPins, colPins, ROWS, COLS);

void setup() {
  for (uint8_t l = 0; l < LEDS; l++) {
    pinMode(ledPins[l], OUTPUT);
    digitalWrite(ledPins[l], LOW);
  }
}

void loop() {
  char key = keypad.getKey();

  if (key != NO_KEY) {
      digitalWrite(ledPins[0], HIGH);
      delay(50);
      digitalWrite(ledPins[0], LOW);

  }

  delay(10);
}